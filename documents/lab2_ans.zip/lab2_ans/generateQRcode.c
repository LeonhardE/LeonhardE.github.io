#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "lib/encoding.h"

// len of Base-32 80-bit secret key
// 80/5=16
#define SECRET_LEN 16

// process hex char to int
int process_char(char target) {
	int result = 0;
    if (target >= '0' && target <= '9') result = target - '0';
    else if (target >= 'A' && target <= 'F') result = target - 'A' + 10;
	return result;
}

int
main(int argc, char * argv[])
{
	if ( argc != 4 ) {
		printf("Usage: %s [issuer] [accountName] [secretHex]\n", argv[0]);
		return(-1);
	}

	char *	issuer = argv[1];
	char *	accountName = argv[2];
	char *	secret_hex = argv[3];

	assert (strlen(secret_hex) <= 20);

	printf("\nIssuer: %s\nAccount Name: %s\nSecret (Hex): %s\n\n",
		issuer, accountName, secret_hex);

	// Create an otpauth:// URI and display a QR code that's compatible
	// with Google Authenticator

	const char * header = "otpauth://totp/";
	const char * middle1 = "?issuer=";
	const char * middle2 = "&secret=";
	const char * middle3 = "&period=30";

	// encode accountName and issuer
	const char * encoded_accountName = urlEncode(accountName);
	const char * encoded_issuer = urlEncode(issuer);

	// process secret_hex
	uint8_t secret[10];
	for (int i = 0; i < 20; i++) {
		secret[i / 2] = process_char(secret_hex[i]) * 16 + process_char(secret_hex[i + 1]);
		i++;
	}

	// encode secret
	char base32_secret[SECRET_LEN];
	base32_encode(secret, 10, (uint8_t *)base32_secret, SECRET_LEN);

	// combine them into URI
	int len = strlen(header) + strlen(encoded_accountName) + strlen(middle1)
			+ strlen(encoded_issuer) + strlen(middle2) + SECRET_LEN + strlen(middle3);
	char URI[len];
	int i = 0;
	for (i = 0; i < strlen(header); i++) URI[i] = header[i];
	for (int j = 0; j < strlen(encoded_accountName); i++, j++) URI[i] = encoded_accountName[j];
	for (int j = 0; j < strlen(middle1); i++, j++) URI[i] = middle1[j];
	for (int j = 0; j < strlen(encoded_issuer); i++, j++) URI[i] = encoded_issuer[j];
	for (int j = 0; j < strlen(middle2); i++, j++) URI[i] = middle2[j];
	for (int j = 0; j < SECRET_LEN; i++, j++) URI[i] = base32_secret[j];
	for (int j = 0; j < strlen(middle3); i++, j++) URI[i] = middle3[j];
	
	displayQRcode(URI);

	return (0);
}
