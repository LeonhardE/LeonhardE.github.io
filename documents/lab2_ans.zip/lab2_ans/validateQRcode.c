#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>
#include <math.h>

#include "lib/sha1.h"

#define TIME_STEP 30
#define MSG_LEN 8
#define KEY_LEN 64
#define IPAD_XOR 0x36
#define OPAD_XOR 0x5c
#define NUM_DIGIT 6

// process hex char to int
int process_char(char target) {
	int result = 0;
    if (target >= '0' && target <= '9') result = target - '0';
    else if (target >= 'A' && target <= 'F') result = target - 'A' + 10;
	return result;
}

static int
validateTOTP(char * secret_hex, char * TOTP_string)
{
	// process secret hex
	uint8_t secret[10];
	for (int i = 0; i < 20; i++) {
		secret[i / 2] = process_char(secret_hex[i]) * 16 + process_char(secret_hex[i + 1]);
		i++;
	}

    unsigned char innerKey[KEY_LEN];
    unsigned char outerKey[KEY_LEN];
	// set values of innerKey and outerKey
    memset(innerKey, 0, sizeof(innerKey));
    memset(outerKey, 0, sizeof(outerKey));
    memcpy(innerKey, secret, 10);
    memcpy(outerKey, secret, 10);
	// xor innerKey and outerKey with ipad and opad
    for (int i = 0; i < KEY_LEN; i++) {
        innerKey[i] ^= IPAD_XOR;
        outerKey[i] ^= OPAD_XOR;
    }

	// Prepare message
    uint8_t message[MSG_LEN];
    uint64_t counter = (time(NULL)) / TIME_STEP;

    for (int i = 0; i < MSG_LEN; i++) {
        message[MSG_LEN - i - 1] = (uint8_t)(counter & 0xff);
        counter >>= 8;
    }

	// Start Hash using SHA1 and get HMAC
	SHA1_INFO ctx;
    uint8_t innerHash[SHA1_DIGEST_LENGTH];
    uint8_t outerHash[SHA1_DIGEST_LENGTH];
	// Inner Hash
	sha1_init(&ctx);
    sha1_update(&ctx, innerKey, KEY_LEN);
    sha1_update(&ctx, message, MSG_LEN);
    sha1_final(&ctx, innerHash);
	// Outer Hash
    sha1_init(&ctx);
    sha1_update(&ctx, outerKey, KEY_LEN);
    sha1_update(&ctx, innerHash, SHA1_DIGEST_LENGTH);
    sha1_final(&ctx, outerHash);

	// from the TOTP paper
	// put selected bytes into result int
    int offset = outerHash[SHA1_DIGEST_LENGTH - 1] & 0xf;
    int binary = ((outerHash[offset] & 0x7f) << 24) |
                 ((outerHash[offset + 1] & 0xff) << 16) |
                 ((outerHash[offset + 2] & 0xff) << 8) |
                 (outerHash[offset + 3] & 0xff);
    int totp = binary % (int)pow(10, NUM_DIGIT);

	int validate = (totp == atoi(TOTP_string));
    return validate;
}


int
main(int argc, char * argv[])
{
	if ( argc != 3 ) {
		printf("Usage: %s [secretHex] [TOTP]\n", argv[0]);
		return(-1);
	}

	char *	secret_hex = argv[1];
	char *	TOTP_value = argv[2];

	assert (strlen(secret_hex) <= 20);
	assert (strlen(TOTP_value) == 6);

	printf("\nSecret (Hex): %s\nTOTP Value: %s (%s)\n\n",
		secret_hex,
		TOTP_value,
		validateTOTP(secret_hex, TOTP_value) ? "valid" : "invalid");

	return(0);
}
